//Author Name: Joseph Lombardo
//Date: 05/13/2021
//Program Name: Lombardo_Drone
//Purpose: Simulation using button, drone movement in x, y,z location

public class Lombardo_Drone {
	
	
	// Initialize variables
	private static int x_pos = 0;
	private static int y_pos = 0;
	private static int z_pos = 0;
	private static int direction = 0;
	private static String orientation = "North";
	
	// Empty constructor method to create drone object
	public Lombardo_Drone() {
	}
	

	// Method to perform actions based on users input
	public void takeAction(Integer input) {
		
		
			// This if else block uses the direction variable to handle the 
			// orientation of the drone without disrupting the y_pos variable
			if(direction > 3 | direction < -3) {
				direction = 0;
			}
			
			if(direction == 0) {
				orientation = "North";
			}
			else if(direction == 1 | direction == -3) {
				orientation = "East";
			}
			else if(direction == 2 | direction == -2) {
				orientation = "South";
			}
			else {
				orientation = "West";
			}
		
		// This switch case block takes users input and performs an action
		// that corresponds to the input
		switch(input) {
		case 1:
			z_pos++;
			System.out.println("You have moved up.");
			break;
		case 2:
			z_pos--;
			System.out.println("You have moved down.");
			break;
		case 3:
			x_pos++;
			System.out.println("You have moved forward.");
			break;
		case 4:
			x_pos--;
			System.out.println("You have moved backwards.");
			break;
		case 5:
			y_pos--;
			direction--;
			System.out.println("You have moved left.");
			break;
		case 6:
			y_pos++;
			direction++;
			System.out.println("You have moved right.");
			break;
		case 7:
			System.out.println("Lombardo_Drone [x_pos=" + x_pos + ", y_pos=" + y_pos + 
					", z_pos=" + z_pos + ", orientation=" + orientation + "]");
			break;
		case 8:
			return;
		}
	}

}

//Author Name: Joseph Lombardo
//Date: 05/13/2021
//Program Name: Lombardo_Drone
//Purpose: Simulation using button, drone movement in x, y,z location
import java.util.Scanner;

public class LombardoMain {
	
	public static void main(String[] args) {

		// Variable to take user input as action choice
		int input = 0;
		
		Scanner scan = new Scanner(System.in);
		
		// Do while loop to first provide user with list of options and repeat
		// options until while condition is met
		do {

			// Instantiate new drone
			Lombardo_Drone drone = new Lombardo_Drone();

			// Provide user with list of options to accept as input
			System.out.println("Which direction would you like to move the drone?");
			System.out.println("1 - Move Up");
			System.out.println("2 - Move Down");
			System.out.println("3 - Move Forward");
			System.out.println("4 - Move Backward");
			System.out.println("5 - Turn Left");
			System.out.println("6 - Turn Right");
			System.out.println("7 - Display Position");
			System.out.println("8 - Exit Navigation");
			
			// Set input variable 
			input = scan.nextInt();
			
			// Call drones takeAction method to perform task based on input variable
			drone.takeAction(input);
		
		// While condition to end program is when user enters 8 as option	
		}while(input != 8);
		scan.close();
	}
	

}
